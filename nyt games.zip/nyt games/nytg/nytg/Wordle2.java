package nytg;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


public class Wordle2 {

    public static void main(String[] args) {
        int WORD_LENGTH = 5;
        int MAX_ATTEMPTS = 6;
        Set<String> dictionary = new HashSet<>();
        List<String> validWords = new ArrayList<>();
        String filename = "dictionary.txt"; // Ensure you have this file
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim().toLowerCase();
                if (line.length() == WORD_LENGTH) {
                    dictionary.add(line);
                    validWords.add(line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading dictionary: " + e.getMessage());
            return;
        }

        if (validWords.isEmpty()) {
            System.out.println("No valid words found in the dictionary!");
            return;

        }
        Random random = new Random();
        String secretWord = validWords.get(random.nextInt(validWords.size()));
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Wordle!");
        System.out.println("Try to guess the " + WORD_LENGTH + "-letter word. You have " + MAX_ATTEMPTS + " attempts.");
        System.out.println("Feedback will be given as follows:");
        System.out.println("🟩 (G) = Correct letter in correct position");
        System.out.println("🟨 (Y) = Correct letter in wrong position");
        System.out.println("⬜ (_) = Letter not in word");

        int attempt = 1;

        while (attempt <= MAX_ATTEMPTS) {

            System.out.print("\nAttempt " + attempt + "/" + MAX_ATTEMPTS + ": ");
            String guess = scanner.nextLine().trim().toLowerCase();
            if (guess.length() != WORD_LENGTH || !dictionary.contains(guess)) {
                System.out.println("Invalid guess! Please enter a valid " + WORD_LENGTH + "-letter word.");
                continue;

            }




            char[] feedback = new char[WORD_LENGTH];
            Arrays.fill(feedback, '_');
            boolean[] usedSecret = new boolean[WORD_LENGTH];
            for (int i = 0; i < WORD_LENGTH; i++) {
                if (guess.charAt(i) == secretWord.charAt(i)) {
                    feedback[i] = 'G';
                    usedSecret[i] = true;
                }
            }
            for (int i = 0; i < WORD_LENGTH; i++) {
                if (feedback[i] == '_') {
                    for (int j = 0; j < WORD_LENGTH; j++) {
                        if (!usedSecret[j] && guess.charAt(i) == secretWord.charAt(j)) {
                            feedback[i] = 'Y';
                            usedSecret[j] = true;
                            break;
                        }
                    }
                }
            }
            System.out.println("Feedback: " + new String(feedback));
            for (int i = 0; i < WORD_LENGTH; i++) {
                char guessChar = guess.charAt(i);
                if (guessChar == secretWord.charAt(i)) {
                    System.out.print("🟩");
                } else if (secretWord.contains(String.valueOf(guessChar))) {
                    System.out.print("🟨");
                } else {
                    System.out.print("⬜"); 
                }
            }
            System.out.println(" " + guess);
            if (guess.equals(secretWord)) {
                System.out.println("\nCongratulations! You've won in " + attempt + " attempts!");
                return;
            }
            attempt++;
        }
        System.out.println("\nGame Over! The word was: " + secretWord);
    }
}