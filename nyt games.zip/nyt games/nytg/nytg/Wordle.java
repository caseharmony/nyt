package nytg;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Wordle {
    private static final int WORD_LENGTH = 5;
    private static final int MAX_ATTEMPTS = 6;
    private static Set<String> dictionary = new HashSet<>();
    private static List<String> validWords = new ArrayList<>();
    
    public static void main(String[] args) {
        loadDictionary("dictionary.txt"); // Make sure you have this file
        if (validWords.isEmpty()) {
            System.out.println("No valid words found in dictionary!");
            return;
        }

        String secretWord = getRandomWord();
        playGame(secretWord);
    }

    private static void loadDictionary(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim().toLowerCase();
                if (line.length() == WORD_LENGTH) {
                    dictionary.add(line);
                    validWords.add(line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading dictionary: " + e.getMessage());
            System.exit(1);
        }
    }

    private static String getRandomWord() {
        Random random = new Random();
        return validWords.get(random.nextInt(validWords.size()));
    }

    private static void playGame(String secretWord) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Wordle!");
        System.out.println("Try to guess the " + WORD_LENGTH + "-letter word. You have " + MAX_ATTEMPTS + " attempts.");
        System.out.println("After each guess, you'll get feedback:");
        System.out.println("🟩 (G) = Correct letter in correct position");
        System.out.println("🟨 (Y) = Correct letter in wrong position");
        System.out.println("⬜ (_) = Letter not in word");

        int attempt = 1;
        while (attempt <= MAX_ATTEMPTS) {
            System.out.print("\nAttempt " + attempt + "/" + MAX_ATTEMPTS + ": ");
            String guess = scanner.nextLine().trim().toLowerCase();

            // Validate guess
            if (guess.length() != WORD_LENGTH) {
                System.out.println("Please enter a " + WORD_LENGTH + "-letter word.");
                continue;
            }

            if (!dictionary.contains(guess)) {
                System.out.println("Not in word list! Please try again.");
                continue;
            }

            // Process the guess
            String feedback = getFeedback(guess, secretWord);
            System.out.println("Feedback: " + feedback);
            
            // Display visual feedback
            displayColorFeedback(guess, secretWord);

            if (guess.equals(secretWord)) {
                System.out.println("\nCongratulations! You've won in " + attempt + " attempts!");
                return;
            }

            attempt++;
        }

        System.out.println("\nGame Over! The word was: " + secretWord);
    }

    private static String getFeedback(String guess, String secretWord) {
        char[] feedback = new char[WORD_LENGTH];
        Arrays.fill(feedback, '_');
        boolean[] usedSecret = new boolean[WORD_LENGTH];

        // First pass: check for correct positions (green)
        for (int i = 0; i < WORD_LENGTH; i++) {
            if (guess.charAt(i) == secretWord.charAt(i)) {
                feedback[i] = 'G';
                usedSecret[i] = true;
            }
        }

        // Second pass: check for correct letters in wrong positions (yellow)
        for (int i = 0; i < WORD_LENGTH; i++) {
            if (feedback[i] == '_') {
                for (int j = 0; j < WORD_LENGTH; j++) {
                    if (!usedSecret[j] && guess.charAt(i) == secretWord.charAt(j)) {
                        feedback[i] = 'Y';
                        usedSecret[j] = true;
                        break;
                    }
                }
            }
        }

        return new String(feedback);
    }

    private static void displayColorFeedback(String guess, String secretWord) {
        for (int i = 0; i < WORD_LENGTH; i++) {
            char guessChar = guess.charAt(i);
            if (guessChar == secretWord.charAt(i)) {
                System.out.print("🟩"); // Green
            } else if (secretWord.contains(String.valueOf(guessChar))) {
                System.out.print("🟨"); // Yellow
            } else {
                System.out.print("⬜"); // Gray
            }
        }
        System.out.println(" ");
        System.out.println(guess);
    }
}
